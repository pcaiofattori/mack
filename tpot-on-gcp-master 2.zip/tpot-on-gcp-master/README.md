# tpot-on-gcp
Deploy tpot to GCE with terraform

# cloud-init source

https://github.com/telekom-security/tpotce/blob/master/cloud/terraform/cloud-init.yaml

# inputs

see `src/terraform/variables.md`